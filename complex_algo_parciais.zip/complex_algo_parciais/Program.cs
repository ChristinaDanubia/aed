﻿namespace complex_algo_parciais;

class Program
{
    static void Main(string[] args)
    {
        SelectionSort.Executar();
        InsertionSort.Executar();

      

    }
}
