public static class InsertionSort{
    
    public static void Executar(){
        
        int[] Ns = { 1000, 1000, 10000 };
        int[] Ks = { 10, 100, 500 };

        for (int teste = 0; teste < 3; teste++)
        {
            int N = Ns[teste];
            int K = Ks[teste];

            Console.WriteLine("===================");
            Console.WriteLine($"N = {N} | K = {K}");
            Console.WriteLine("===================");

            
            int[] ordenado = CriarVetorOrdenado(N);
            ExecutarTeste(ordenado, N, K, "Ordenado");

            
            int[] inverso = CriarVetorInverso(N);
            ExecutarTeste(inverso, N, K, "Inverso");

            
            int[] aleatorio = CriarVetorAleatorio(N);
            ExecutarTeste(aleatorio, N, K, "Aleatório");
        }
    }


    static int[] CriarVetorOrdenado(int N)
    {
        int[] vetor = new int[N];

        for (int i = 0; i < N; i++)
        {
            vetor[i] = i + 1;
        }

        return vetor;
    }


    static int[] CriarVetorInverso(int N)
    {
        int[] vetor = new int[N];

        for (int i = 0; i < N; i++)
        {
            vetor[i] = N - i;
        }

        return vetor;
    }


    static int[] CriarVetorAleatorio(int N)
    {
        int[] vetor = new int[N];

        Random random = new Random();

        for (int i = 0; i < N; i++)
        {
            vetor[i] = random.Next(1, N + 1);
        }

        return vetor;
    }


    static void InsertionSortParcial(int[] vetor, int K, ref long comparacoes, ref long movimentacoes){

        int N = vetor.Length;

        for (int i = 1; i < N; i++)
        {
            int chave = vetor[i];
            movimentacoes++;
        
            if (i < K)
            {
                comparacoes++;

                if (chave < vetor[i - 1])
                {
                    int j = i - 1;

                    while (j > 0)
                    {
                        comparacoes++;

                        if (vetor[j - 1] > chave)
                        {
                            vetor[j] = vetor[j - 1];
                            movimentacoes++;

                            j--;
                        }
                        else
                        {
                            break;
                        }
                    }

                    vetor[j] = chave;
                    movimentacoes++;
                }
            }
            else
            {
                comparacoes++;

                if (chave < vetor[K - 1])
                {
                    int j = K - 1;

                    while (j > 0)
                    {
                        comparacoes++;

                        if (vetor[j - 1] > chave)
                        {
                            vetor[j] = vetor[j - 1];
                            movimentacoes++;

                            j--;
                        }
                        else
                        {
                            break;
                        }
                    }

                    vetor[j] = chave;
                    movimentacoes++;
                }
            }
        }
    }


    static void ExecutarTeste(int[] vetor, int N, int K, string tipo){
        long comparacoes = 0;
        long movimentacoes = 0;

        InsertionSortParcial(
            vetor,
            K,
            ref comparacoes,
            ref movimentacoes
        );

        Console.WriteLine($"N: {N} | K: {K} | Entrada: {tipo}");
        Console.WriteLine($"Comparações: {comparacoes}");
        Console.WriteLine($"Movimentações: {movimentacoes}");
        Console.WriteLine();
    }
}